    <?php $__env->startSection('head'); ?>
        <title>Mutasi</title> 
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('contents'); ?>
        <h3>Daftar Mutasi</h3>

        <table class="table table-striped mt-3" id="myTable">
                <tbody>
                    <tr>
                        <th>Cari Anggota</th>
                        <th>
                                <select class="form-control"onchange="mutasi()" id="mutasi">
                                        <option>Pilih Anggota</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        </th>
                </tbody>
        </table>
        <div id="result">

        </div>
    <?php $__env->stopSection(); ?> 
    <script type="text/javascript">
        function mutasi(){
        var mutasi      = $("#mutasi").val();
             $('#result').html('<center>Searching ...</center>'); // Show "Downloading..."
             jQuery.ajax({
                    type: "GET",
                    url: "",
                    data:  {user_id: mutasi},
                    success:function(data){
                     $('#result').html(data);
                    }
            });
        }
    </script>
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('./template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>