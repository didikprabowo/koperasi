    <?php $__env->startSection('head'); ?>
        <title>Anggota</title> 
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('contents'); ?>
        <h3>Selamat Datang di koperasi simpanan<h3
    <?php $__env->stopSection(); ?> 
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('./template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>