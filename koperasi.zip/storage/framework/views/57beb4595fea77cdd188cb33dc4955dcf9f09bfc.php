    <?php $__env->startSection('head'); ?>
        <title>Tambah Anggota</title> 
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('contents'); ?>
            <h2>Tambah Anggota</h2>
            <form action="<?php echo e(url('anggota')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label>Name:</label>
                  <input type="name" class="form-control" placeholder="Enter Name" name="name" required>
                </div>
                <div class="form-group">
                  <label>Email:</label>
                  <input type="email" class="form-control" placeholder="Enter Email" name="email" required>
                </div>
                <div class="form-group">
                        <label>Address:</label>
                        <textarea class="form-control" cols="5" placeholder="Enter Your Address" name="alamat" required></textarea>
                </div>
                <div class="form-group">
                        <label>No.Hp:</label>
                        <input type="number" class="form-control" placeholder="Enter Number"  min="1" minlength="11" name="no_hp" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </form>
    <?php $__env->stopSection(); ?>

<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('./template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>