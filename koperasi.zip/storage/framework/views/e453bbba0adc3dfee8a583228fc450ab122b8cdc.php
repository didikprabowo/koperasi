    <?php $__env->startSection('head'); ?>
        <title>Anggota</title> 
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('contents'); ?>
        <h3>Daftar Anggota</h3>
        <a href="<?php echo e(url('anggota/create')); ?>" class="btn btn-primary btn-sm ">Tambah Anggota</a>
        <table class="table table-striped mt-3" id="myTable">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>No.Hp</th>
                    <th>Bergabung</th>
                    <th>Action<th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no=1;   
                ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($user->name); ?>

                        <td><?php echo e($user->email); ?>

                        <td><?php echo e($user->alamat); ?>

                        <td><?php echo e($user->no_hp); ?>

                        <td><?php echo e(date('m/d/Y H:i:s', strtotime($user->created_at))); ?></td>
                        <td>
                            <form action="<?php echo e(route('anggota.destroy', $user->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <a type="submit" class="btn btn-info btn-sm" href="<?php echo e(route('anggota.edit',$user->id)); ?>">Edit</a>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Hapus data?')">Delete</button>
                            </form>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            <?php echo e($users->links()); ?>

    <?php $__env->stopSection(); ?> 
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('./template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>