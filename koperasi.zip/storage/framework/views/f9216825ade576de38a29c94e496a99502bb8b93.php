    <?php $__env->startSection('head'); ?>
        <title> Setor Tunai</title> 
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('contents'); ?>
            <h2>Setor Tunai</h2>
            <form action="<?php echo e(route('transaksi.setor')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                <label>Anggota:</label>
                <select class="form-control" name="user_id">
                        <option>Pilih Anggota</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                <div class="form-group">
                    <label>Nominal:</label>
                    <input type="number" class="form-control"  name="nominal" min="1" placeholder="Nominal" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
    <?php $__env->stopSection(); ?>

<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('./template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>