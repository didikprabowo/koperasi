@extends('./template')
    @section('head')
        <title>Anggota</title> 
    @endsection
    @section('contents')
        <h3>Selamat Datang di koperasi simpanan<h3
    @endsection 
@show