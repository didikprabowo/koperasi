# Koperasi Tabungan
## Panduan Instalasi
### Database 
1. Buat database baru, contohnya dengan nama `` koperasi ``
2. Import File SQL ke dalam database yang sudah di buat.

### Sistem
1. Ubah file .env.example menjadi .env
2. Lakukan konfigurasi mengenai Database sesuai dengan env yang ada.

## Panduan Menggunakan
1. Apabila tidak menggunakan web server dapat menggunakan perintah `` php artisan serve `` untuk menjalankannya. Pastikan berada di directory projek.
2. Buka di browser callback dari perintah di atas.
3. Akses Login dapat menggunakan akun ,
  email : didik@gmail.com ,
  password : didik
